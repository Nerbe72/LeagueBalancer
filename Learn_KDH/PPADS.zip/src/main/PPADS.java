package main;

import execWork.PlayPy;

public class PPADS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PlayPy pp = new PlayPy();
	}

}
