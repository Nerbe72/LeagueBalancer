package server;

public class javaServer {
	
}
