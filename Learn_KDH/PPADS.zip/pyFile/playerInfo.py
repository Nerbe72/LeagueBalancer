def output(name):
    for i in name:
        print("{0}".format(i))

def main():
    name = ["김동현", "이호진", "정회민", "최성원"]
    output(name)
    
main()
